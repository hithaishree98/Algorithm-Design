def merge_arrays(arr, m, aux, n):
    min_size = min(m, n)
    
    for i in range(min_size):
        aux[i] = arr[i]

    i = 0
    j = 0
    k = m

    while i < min_size and j < n:
        if aux[i] <= arr[k]:
            arr[i + j] = aux[i]
            i += 1
        else:
            arr[i + j] = arr[k]
            k += 1
            j += 1

    while i < min_size:
        arr[i + j] = aux[i]
        i += 1

def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2
        left_half = arr[:mid]
        right_half = arr[mid:]

        merge_sort(left_half)
        merge_sort(right_half)

        i = j = k = 0

        while i < len(left_half) and j < len(right_half):
            if left_half[i] <= right_half[j]:
                arr[k] = left_half[i]
                i += 1
            else:
                arr[k] = right_half[j]
                j += 1
            k += 1

        while i < len(left_half):
            arr[k] = left_half[i]
            i += 1
            k += 1

        while j < len(right_half):
            arr[k] = right_half[j]
            j += 1
            k += 1

test_cases = [
    ([], [3, 7, 9]),
    ([2, 7, 9], [1]),
    ([1, 7, 10, 15], [3, 8, 12, 18]),
    ([1, 3, 5, 5, 15, 18, 21], [5, 5, 6, 8, 10, 12, 16, 17, 17, 20, 25, 28])
]

for idx, (subarray1, subarray2) in enumerate(test_cases, start=1):
    m = len(subarray1)
    n = len(subarray2)
    arr = subarray1 + subarray2
    aux = [0] * min(m, n)

    merge_arrays(arr, m, aux, n)
    merge_sort(arr)

    print(f"Test Case {idx}: Merged and Sorted Array - {arr}")
