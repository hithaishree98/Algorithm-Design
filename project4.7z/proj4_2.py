def ala_carte_karatsuba(x, y):
    sign = 1
    if x < 0:
        sign = -sign
        x = abs(x)
    if y < 0:
        sign = -sign
        y = abs(y)
    
    if x < 10 or y < 10:
        return sign * x * y
    
    n = max(len(str(x)), len(str(y)))
    nby2 = n // 2
    
    a = x // 10 ** (nby2)
    b = x % 10 ** (nby2)
    c = y // 10 ** (nby2)
    d = y % 10 ** (nby2)
    
    ac = ala_carte_karatsuba(a, c)
    bd = ala_carte_karatsuba(b, d)
    ad_plus_bc = ala_carte_karatsuba(a + b, c + d) - ac - bd
    
    return sign * ((ac * 10 ** (2 * nby2)) + (ad_plus_bc * 10 ** (nby2)) + bd)


def rectangle_multiplication(x, y):
    sign = 1
    
    if x < 0:
        sign = -sign
        x = -x
    
    if y < 0:
        sign = -sign
        y = -y
    
    result = 0
    while y > 0:
        if y % 2 == 1:
            result += x
        x <<= 1
        y >>= 1
        
    return result if sign > 0 else -result

test_cases = [
    (7000, 7294),
    (25, 5038385),
    (-59724, 783),
    (8516, -82147953548159344),
    (45952456856498465985, 98654651986546519856),
    (-45952456856498465985, -98654651986546519856)
]

for idx, (a, b) in enumerate(test_cases, start=1):
    ala_carte_result = ala_carte_karatsuba(a, b)
    rectangle_result = rectangle_multiplication(a, b)
    
    print(f"Test Case {idx}:")
    print(f"Ala Carte Multiplication Result: {ala_carte_result}")
    print(f"Rectangle Multiplication Result: {rectangle_result}")
    print()
