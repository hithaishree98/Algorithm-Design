import java.util.*;

public class HowSum {
    public static List<Integer> howSum(int targetSum, int[] numbers, Map<Integer, List<Integer>> memo) {
        if (memo.containsKey(targetSum)) {
            return memo.get(targetSum);
        }
        
        if (targetSum == 0) {
            return new ArrayList<>();
        }
        
        if (targetSum < 0) {
            return null;
        }
        
        for (int num : numbers) {
            int remainder = targetSum - num;
            List<Integer> result = howSum(remainder, numbers, memo);
            if (result != null) {
                result.add(num);
                memo.put(targetSum, result);
                return result;
            }
        }
        
        memo.put(targetSum, null);
        return null;
    }
    
    public static void main(String[] args) {
        Map<Integer, List<Integer>> memo = new HashMap<>();
        System.out.println(howSum(7, new int[]{2, 3}, memo));  // Output: [2, 2, 3]
        memo.clear();
        System.out.println(howSum(7, new int[]{5, 3, 4, 7}, memo));  // Output: [3, 4]
        memo.clear();
        System.out.println(howSum(300, new int[]{7, 14}, memo));  // Output: null
    }
}
