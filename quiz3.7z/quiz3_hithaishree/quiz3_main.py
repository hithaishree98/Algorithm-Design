def backtrack_subsets(n):
    def backtrack(start, subset):
        subsets.append(subset[:])
        for i in range(start, n + 1):
            subset.append(i)
            backtrack(i + 1, subset)
            subset.pop()

    subsets = []
    backtrack(1, [])
    return subsets

def count_subsets(n):
    return 2 ** n

def main():
    test_cases = [3, 5, 7]

    for n in test_cases:
        subsets = backtrack_subsets(n)
        total_count = count_subsets(n)
        
        print(f"Subsets of {{1, 2, ..., {n}}}:")
        for subset in subsets:
            print(subset)
        
        print(f"Total Subset Count for n={n}: {total_count}")
        print()

if __name__ == "__main__":
    main()
