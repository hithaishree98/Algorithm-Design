def karatsuba(x, y):
    if abs(x) < 10 or abs(y) < 10:
        return x * y

    n = max(len(str(abs(x))), len(str(abs(y))))
    n2 = n // 2

    # Split x and y into two parts
    high1, low1 = divmod(x, 10**n2)
    high2, low2 = divmod(y, 10**n2)

    # Recursive calls
    z0 = karatsuba(low1, low2)
    z1 = karatsuba((low1 + high1), (low2 + high2))
    z2 = karatsuba(high1, high2)

    # Combine results
    result = (z2 * 10**(2*n2)) + ((z1 - z2 - z0) * 10**n2) + z0

    # Handle negative numbers
    if x < 0 and y >= 0:
        return -result
    elif x >= 0 and y < 0:
        return -result
    else:
        return result

# Test Cases
print(karatsuba(7000, 7294))  # Test Case 1
print(karatsuba(25, 5038385))  # Test Case 2
print(karatsuba(-59724, 783))  # Test Case 3
print(karatsuba(8516, -82147953548159344))  # Test Case 4
print(karatsuba(45952456856498465985, 98654651986546519856))  # Test Case 5
print(karatsuba(-45952456856498465985, -98654651986546519856))  # Test Case 6
