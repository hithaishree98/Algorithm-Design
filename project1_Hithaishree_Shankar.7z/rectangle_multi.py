def rectangle_multiplication(num1, num2):
    # Convert the multiplicands to strings
    str_num1 = str(abs(num1))
    str_num2 = str(abs(num2))
    
    # Initialize the result to 0
    result = 0
    
    # Iterate over each digit of num1 in reverse order
    for i in range(len(str_num1) - 1, -1, -1):
        digit1 = int(str_num1[i])
        
        # Reset the carry for each new digit of num1
        carry = 0
        
        # Initialize a temporary result for this digit
        temp_result = 0
        
        # Iterate over each digit of num2 in reverse order
        for j in range(len(str_num2) - 1, -1, -1):
            digit2 = int(str_num2[j])
            
            # Calculate the product of the current digits and add the carry
            product = digit1 * digit2 + carry
            
            # Update the temporary result and carry for the next iteration
            temp_result = temp_result * 10 + product % 10
            carry = product // 10
        
        # If there is a carry left, add it to the temporary result
        if carry > 0:
            temp_result = temp_result * 10 + carry
        
        # Shift the temporary result left by the appropriate number of positions
        temp_result *= 10 ** (len(str_num1) - 1 - i)
        
        # Add the temporary result to the overall result
        result += temp_result
    
    # Determine the sign of the result based on the signs of the input numbers
    if (num1 < 0 and num2 >= 0) or (num1 >= 0 and num2 < 0):
        result = -result
    
    return result

# Test cases
test_cases = [
    (7000, 7294),
    (25, 5038385),
    (-59724, 783),
    (8516, -82147953548159344),
    (45952456856498465985, 98654651986546519856),
    (-45952456856498465985, -98654651986546519856)
]

for i, (num1, num2) in enumerate(test_cases):
    result = rectangle_multiplication(num1, num2)
    print(f"Test Case {i + 1}: {num1} * {num2} = {result}")
