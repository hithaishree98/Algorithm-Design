def merge_sorted_arrays(A, m, B, n):
    # Create an auxiliary array to store the merged result
    aux = [0] * (m + n)

    # Initialize pointers for A, B, and aux
    i = 0  # Pointer for A
    j = 0  # Pointer for B
    k = 0  # Pointer for aux

    # Merge elements from A and B into aux
    while i < m and j < n:
        if A[i] <= B[j]:
            aux[k] = A[i]
            i += 1
        else:
            aux[k] = B[j]
            j += 1
        k += 1

    # Copy any remaining elements from A (if any)
    while i < m:
        aux[k] = A[i]
        i += 1
        k += 1

    # Copy any remaining elements from B (if any)
    while j < n:
        aux[k] = B[j]
        j += 1
        k += 1

    print(aux)

# Test Cases
A1 = []
B1 = [3, 7, 9]
merge_sorted_arrays(A1, 0, B1, len(B1))

A2 = [2, 7, 9]
B2 = [1]
merge_sorted_arrays(A2, len(A2), B2, len(B2))

A3 = [1, 7, 10, 15]
B3 = [3, 8, 12, 18]
merge_sorted_arrays(A3, len(A3), B3, len(B3))

A4 = [1, 3, 5, 5, 15, 18, 21]
B4 = [5, 5, 6, 8, 10, 12, 16, 17, 17, 20, 25, 28]
merge_sorted_arrays(A4, len(A4), B4, len(B4))
