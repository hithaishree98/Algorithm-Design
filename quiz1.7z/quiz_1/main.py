def generate_subsets(arr, subset_size, current_index=0, current_subset=[]):
    if len(current_subset) == subset_size:
        print(current_subset)
        return

    if current_index >= len(arr):
        return

    # Include the current element in the subset
    current_subset.append(arr[current_index])
    generate_subsets(arr, subset_size, current_index + 1, current_subset)

    # Exclude the current element from the subset
    current_subset.pop()
    generate_subsets(arr, subset_size, current_index + 1, current_subset)

def print_subsets_of_size_three(arr):
    if len(arr) < 3:
        print("The input set does not have enough elements to form subsets of size 3.")
        return

    generate_subsets(arr, 3)

# Example usage:
input_set1 = [1, 2, 3, 4]
print_subsets_of_size_three(input_set1)

input_set2 = [7,3]
print_subsets_of_size_three(input_set2)

input_set3 = [4,1,7,4,3,9,1,5]
print_subsets_of_size_three(input_set3)
